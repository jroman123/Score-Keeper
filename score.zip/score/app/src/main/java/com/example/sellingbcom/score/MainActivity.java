package com.example.sellingbcom.score;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.TextView;

import com.example.sellingbcom.score.R;

import java.text.NumberFormat;

/**
 * This app displays an order form to order coffee.
 */
public class MainActivity extends ActionBarActivity {
    int scoreA = 0;
    int scoreB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * Add Coffees.
     */
    public void teamAThree(View view) {

        scoreA = scoreA + 3;
        displayA(scoreA);

    }

    /**
     * Substract Coffees.
     */
    public void teamATwo(View view) {

        scoreA = scoreA + 2;
        displayA(scoreA);

    }

    /**
     * This method is called when the order button is clicked.
     */
    public void teamAFree(View view) {

        scoreA = scoreA + 1;
        displayA(scoreA);

    }


    /**
     * Displays the given score for Team A.
     */
    public void displayA(int numberA) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText(String.valueOf(scoreA));
    }

    /**
     * Add Coffees.
     */
    public void teamBThree(View view) {

        scoreB = scoreB + 3;
        displayB(scoreB);

    }

    /**
     * Substract Coffees.
     */
    public void teamBTwo(View view) {

        scoreB = scoreB + 2;
        displayB(scoreB);

    }

    /**
     * This method is called when the order button is clicked.
     */
    public void teamBFree(View view) {

        scoreB = scoreB + 1;
        displayB(scoreB);

    }


    /**
     * Displays the given score for Team A.
     */
    public void displayB(int numberB) {
        TextView scoreView = (TextView) findViewById(R.id.team_b_score);
        scoreView.setText(String.valueOf(scoreB));
    }

    public void reset(View view) {
        scoreA = 0;
        displayA(scoreA);
        scoreB = 0;
        displayB(scoreB);

    }
}