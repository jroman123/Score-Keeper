//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\ README FILE - 7/23/2016 - "Basket Ball Score Keeper" - Score Calculator Android App
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

A. DISCLAIMER
This disclaimer appoints that the content provided in this app is based on personal opinions and theories, and in no circumstance be utilized as factual content unless proven by an expert in the field of the subject.
This app was developed for educational purposes and to share a personal inside on the subject. Basket Ball Score Keeper app is not responsible for, and expressly disclaims all liability for, damages of any kind arising out of use, reference to, or reliance on any information contained within the app.

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

B. CONTENT
Topic --> Basket Ball Score Keeper

This App keeps track of a gaming score between two teams. By pressing bewteen three choices either 3 points, 2 points or free throw equivalent to 1 point, the
app arithmetic code will add each click respectively for each team. At the end of the game the counter can be cleared for a new game by pressing the reset button.

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

C. OPERATIONAL ALGORITHM
1. Open App
2. Press button of coice for the proper team.
3. At the end of game, press the 'Reset' button.
4. Exit App

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

D. ALGORITHM HIERARCHY

                                                                         +----------+
									 | OPEN APP |
									 +----------+
									       ^
								      	       |
								        +--------------+	   
									| Click Button |
                                                                        +--------------+
                                                                               ^
                                                                               |
				                                          +----------+
				                                          | 3 Points |			
				                                          +----------+		    
				                                          +----------+			
                                                                          | 2 Points |                  										
                                                                          +----------+                   
			                                                  +----------+     		  
                                                                          | 1 Points |                   
				                                          +----------+	                       
                                                                                ^
								        	|
									+--------------+		
									| Press Reset  |
									+--------------+
									        ^
										|
							                  +----------+		
							                  | Exit App |
							                  +----------+
							       
							   


